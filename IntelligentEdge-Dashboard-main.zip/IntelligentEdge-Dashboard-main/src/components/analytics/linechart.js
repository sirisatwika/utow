import React, { useState,useEffect } from "react";
import axios from "axios";
import ReactApexChart from "react-apexcharts";
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import DatePicker from "react-datepicker";
import "../datacollection/telementrydata/datepicker.css";

function LineChart(props) {
      //console.log(props);
  
  const [devices, setDevices] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
    axios.get(`http://localhost:5000/gatewaydata/api/v1/name/getdevicenames/all`)
		.then(response =>{
		//console.log(response.data);
		setDevices(response.data); 
		})
  }
  fetchData();
  },[]);
  
  const [selectdevice, setdevice] = React.useState('CarbondioxideSensor');
  
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
    axios.get(`http://localhost:5000/gatewaydata/api/v1/data/linegraph/${selectdevice}`)
		.then(response =>{
		//console.log(response.data);
		setData(response.data); 
		})
  }
  fetchData();
  },[]);
  
  
  //Selct device Dropdown
  const devicehandleChange = (event) => {
    setdevice(event.target.value);

     
    const fetchData = async () => {
    axios.get(`http://localhost:5000/gatewaydata/api/v1/data/linegraph/${selectdevice}`)
		.then(response =>{
		//console.log(response.data);
		setData(response.data); 
		})
  }
  fetchData();
  };


  //Date Range Picker options
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;

  //For Line chart series options
  const series = [
   {devicename: props.devicename,
    data : Object.values(data)
    }
    ];
    
//console.log(series);
  const chartOptions = {
    chart: {
      height: 350,
      type: 'line',
      dropShadow: {
        enabled: false,
        color: '#000',
        top: 18,
        left: 7,
        blur: 10,
        opacity: 1
      },
      toolbar: {
        show: false
      }
    },
    colors: ['#D61355', '#F94A29', '#0081C9', '#A31ACB', '#FF78F0', '#379237', '#0E185F', '#00D7FF', '#F55353'],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: 'straight',
      width: 1.3
    },
    grid: {
      borderColor: '#ddd',
      row: {
        colors: ['transparent', 'transparent'],
        opacity: 0.1
      },
    },
    markers: {
      size: 0
    },
    xaxis: {
      categories: Object.keys(data),
      labels: {
        show: true,
        style: {
          fontSize: '12px',
          fontFamily: 'Raleway, sans-serif',
          fontWeight: 500,
        },
      },
      title: {
        text: 'Time(Hrs)',
        offsetY: 90,
        style: {
          color: '#3f51b5',
          fontSize: '12px',
          fontFamily: 'Raleway, sans-serif',
          fontWeight: 'bold',
        },
      },
    },
    yaxis: {
      labels: {
        show: true,
        align: 'right',
        minWidth: 0,
        maxWidth: 160,
        style: {
          fontSize: '12px',
          fontFamily: 'Raleway, sans-serif',
          fontWeight: 500,
        },
      },
      axisBorder: {
        show: true,
        color: '#ccc',
      },
      title: {
        text: 'Value',
        style: {
          color: '#3f51b5',
          fontSize: '12px',
          fontFamily: 'Raleway, sans-serif',
          fontWeight: 'bold',
        },
      },
      min: -500,
      max: 500
    },
    legend: {
      position: 'right',
      horizontalAlign: 'bottom',
      floating: false,
      offsetY: 20,
      offsetX: -30,
      fontSize: '12px',
      fontFamily: 'Raleway, sans-serif',
      fontWeight: 600,
      height: 200,
      width: 160,
    }
  };

  return (
    <React.Fragment>
      <div className="dropdownselect">
        <div className="selectdropdown">
          <DatePicker
            selectsRange={true}
            startDate={startDate}
            endDate={endDate}
            onChange={(update) => {
             setDateRange(update);
            }}
            isClearable={true}
            showIcon
            placeholderText="Select Start & End Date"
            closeOnScroll={true}
          />
        </div>

        <div className="selectdropdown">
          <FormControl sx={{ m: 1, minWidth: 170 }} size="small">
            <InputLabel id="demo-select-small">Select Device</InputLabel>
            <Select labelId="demo-select-small" id="demo-select-small" value={selectdevice} label="Select Device" onChange={devicehandleChange}>
              {devices.map(item =>(
              	<MenuItem key={item} value={item}>
              	{item}
              	</MenuItem>
              ))}
              </Select>
          </FormControl>
        </div>
      </div>
      <div id="chart">
        <ReactApexChart options={chartOptions} series={series} type="line" height={320} />
      </div>
    </React.Fragment>
  )
}
export default LineChart;
