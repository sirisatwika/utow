import React from "react";
import AddIcon from '@mui/icons-material/Add';

function EndPoint(){
  return(
    <React.Fragment>
      <div className="endpointicons"><AddIcon/></div>
    </React.Fragment>
  )
}
export default EndPoint;
